function changeBackground() {
    document.body.style.backgroundColor = "lightblue";
}
